# Exotic Studios

Black and red portfolio website for Exotic Studios.

## Upload to GitHub

1. Create a new GitHub repository.
2. Upload `index.html`.
3. If using GitHub Pages, enable Pages from the repository settings.
4. For Vercel, import the repository and deploy it as a static site.

Discord:
- Username: e.puz
- Invite: https://discord.gg/BaSSMxjvdU

Footer:
© 2026 GreenedBox Customs. All rights reserved.
